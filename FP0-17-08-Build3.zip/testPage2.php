<nav>
	<div class="mobile-menu">
		<div class="branding">
			<a href="http://blocklogix.icontest2.com">
				<img src="http://blocklogix.icontest2.com/wp-content/uploads/2018/02/logo.svg" alt="Block Logix" scale="0">
			</a>
		</div>
		<div class="hamburger">
			<span class="menu-more" style="display: block;"><svg class="svg-inline--fa fa-bars fa-w-14" aria-hidden="true" data-prefix="fal" data-icon="bars" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" data-fa-i2svg=""><path fill="currentColor" d="M442 114H6a6 6 0 0 1-6-6V84a6 6 0 0 1 6-6h436a6 6 0 0 1 6 6v24a6 6 0 0 1-6 6zm0 160H6a6 6 0 0 1-6-6v-24a6 6 0 0 1 6-6h436a6 6 0 0 1 6 6v24a6 6 0 0 1-6 6zm0 160H6a6 6 0 0 1-6-6v-24a6 6 0 0 1 6-6h436a6 6 0 0 1 6 6v24a6 6 0 0 1-6 6z"></path></svg><!-- <i class="fal fa-bars"></i> --></span>
			<span class="menu-close" style="display: none;"><svg class="svg-inline--fa fa-times fa-w-12" aria-hidden="true" data-prefix="fal" data-icon="times" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512" data-fa-i2svg=""><path fill="currentColor" d="M217.5 256l137.2-137.2c4.7-4.7 4.7-12.3 0-17l-8.5-8.5c-4.7-4.7-12.3-4.7-17 0L192 230.5 54.8 93.4c-4.7-4.7-12.3-4.7-17 0l-8.5 8.5c-4.7 4.7-4.7 12.3 0 17L166.5 256 29.4 393.2c-4.7 4.7-4.7 12.3 0 17l8.5 8.5c4.7 4.7 12.3 4.7 17 0L192 281.5l137.2 137.2c4.7 4.7 12.3 4.7 17 0l8.5-8.5c4.7-4.7 4.7-12.3 0-17L217.5 256z"></path></svg><!-- <i class="fal fa-times"></i> --></span>
		</div>
	</div>
	<div class="blocklogix--header__menus">
		<div class="menu-main-menu-container"><ul id="primary-menu" class="main-menu"><li id="menu-item-206" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-206"><a href="http://blocklogix.icontest2.com/about-us/">About Us</a></li>
				<li id="menu-item-67" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-67"><a href="http://blocklogix.icontest2.com/workshops/">Workshops</a></li>
				<li id="menu-item-253" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-253"><a href="http://blocklogix.icontest2.com/consulting/">Consulting</a></li>
				<li id="menu-item-65" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-65"><a href="http://blocklogix.icontest2.com/seminars/">Seminars</a></li>
				<li id="menu-item-254" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-254"><a href="http://blocklogix.icontest2.com/news/">News</a></li>
			</ul></div><div class="menu-secondary-menu-container"><ul id="secondary-menu" class="secondary-menu"><li id="menu-item-1443" class="cartBtnContainer menu-item menu-item-type-post_type menu-item-object-page menu-item-1443"><a href="http://blocklogix.icontest2.com/cart/">Cart</a></li>
				<li id="menu-item-172" class="btn yellow-btn menu-item menu-item-type-custom menu-item-object-custom menu-item-172"><a href="/contact-us">Contact Us</a></li>
				<li id="menu-item-wpml-ls-17-de" class="menu-item wpml-ls-slot-17 wpml-ls-item wpml-ls-item-de wpml-ls-menu-item wpml-ls-first-item wpml-ls-last-item menu-item-type-wpml_ls_menu_item menu-item-object-wpml_ls_menu_item menu-item-wpml-ls-17-de"><a title="Deutsch" href="http://blocklogix.icontest2.com/de/"><span class="wpml-ls-native">Deutsch</span></a></li>
			</ul></div>				</div>
</nav>