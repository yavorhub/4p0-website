	<?php get_header(); ?>
<div class="content-container">
	<div class="intro-content" >
		<div class="circle-big-center">
			<div id="container" style="text-align: center;">
				<div id="logo-image"></div>
				<div id="intro-title">ELEKTROPLANUNG</div>
				<div id="intro-text"><p class="front-page-text">Bauprojekte sind nicht mehr kompliziert – sie sind komplex geworden</p></div>
				<div id="intro-mail"><p class="front-page-text"><a href="mailto:office@4p0.ch">office@4p0.ch</a></p></div>
				<div id="intro-link"><a href="wp/about" ><span class="link-color">MEHR
							<i class="fal fa-long-arrow-right"></i>
						</span></a></div>
			</div>
		</div>
	</div>
</div>
	<?php get_footer();?>

