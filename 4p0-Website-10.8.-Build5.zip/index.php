<?php wp_header();?>
	<p>Index php</p>
<?php wp_footer(); // Crucial footer hook! ?>
