<?php get_header(); ?>
<h1><?php var_dump(get_fields()) ?></h1>

<?php get_footer(); ?>
