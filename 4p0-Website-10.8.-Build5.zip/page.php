<div class="content-container">
	<?php get_header(); ?>
	<div class="intro-content">
		<div class="circle-big-center">
			<div id="container" style="text-align: center;">
				<div id="logo-image"></div>
				<div id="intro-title">ELEKTROPLANUNG</div>
				<div id="intro-text"><p>Bauprojecte sind nicht mehr komliziert - sie sind complex geworden</p></div>
				<div id="intro-mail"><p>office@4p0.ch</p></div>
				<div id="intro-link"><a href="" ><span class="link-color">LEARN MORE -></span></a></div>
			</div>
		</div>
	</div>
</div>


