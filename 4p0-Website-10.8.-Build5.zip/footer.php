<footer>
		<div class="normal-text" ">
			VIERPUNKTNULL - ELEKTROPLANUNG
		</div>
	
		<div class="normal-text">
			<div class="inner-div-float-right" >
				<p>Bubikerstrasse1 </p>
				<p>8645Rapperswil-Jona</p>
				<p><a href="mailto:ofice@4p0.ch">ofice@4p0.ch</a></p>
			</div>
		</div>
</footer>

<?php wp_footer() ; ?>
</main>
</body>
</html>